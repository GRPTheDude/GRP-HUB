﻿using System.Windows.Controls;

namespace Haze
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }

        private void PlayB_Click(object sender, System.Windows.RoutedEventArgs e)
        {

        }
    }
}
