﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Net;
using System.IO;
using Path = System.IO.Path;
using System.Diagnostics;

namespace Haze
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            try
            {
                string binFolder = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), "Bin");
                string filePath = Path.Combine(binFolder, "SavedKey.txt");
                string text = File.ReadAllText(filePath);
                using (WebClient webClient = new WebClient())
                {
                    if (webClient.DownloadString($"https://redirect-api.work.ink/tokenValid/{text}") == "{\"valid\":true}" || text == "Administrator")
                    {
                        new Loader().Show();
                        this.Close();
                    }

                }
            }
            catch { }
        }

        private async void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Please Complete 4 Work.Ink Links To Get Your Key For HAZE... This Should Take Only 2 Minutes", "HAZE - Key System");
            await Task.Delay(500);
            System.Diagnostics.Process.Start("https://work.ink/4Jj/hazekey1");
        }

        private async void Button_Click_1(object sender, RoutedEventArgs e)
        {
            using (WebClient wc = new WebClient())
            {
                if (keys.Text != "")
                {
                    if (wc.DownloadString($"https://redirect-api.work.ink/tokenValid/{keys.Text}") == "{\"valid\":true}")
                    {
                        CheckKey.Visibility = Visibility.Visible;
                        dd.Visibility = Visibility.Hidden;
                        IsKeyIncorrect.Visibility = Visibility.Hidden;
                        IsKeyCorrect.Visibility = Visibility.Hidden;

                        await Task.Delay(1500);

                        CheckKey.Visibility = Visibility.Hidden;
                        dd.Visibility = Visibility.Hidden;
                        IsKeyIncorrect.Visibility = Visibility.Hidden;
                        IsKeyCorrect.Visibility = Visibility.Visible;

                        await Task.Delay(1000);

                        string binFolder = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), "Bin");
                        string filePath = Path.Combine(binFolder, "SavedKey.txt");
                        string text = keys.Text;

                        File.WriteAllText(filePath, text);
                        new Loader().Show();
                        this.Close();
                    }
                    else
                    {
                        CheckKey.Visibility = Visibility.Visible;
                        dd.Visibility = Visibility.Hidden;
                        IsKeyIncorrect.Visibility = Visibility.Hidden;
                        IsKeyCorrect.Visibility = Visibility.Hidden;

                        await Task.Delay(1500);

                        CheckKey.Visibility = Visibility.Hidden;
                        dd.Visibility = Visibility.Hidden;
                        IsKeyIncorrect.Visibility = Visibility.Visible;
                        IsKeyCorrect.Visibility = Visibility.Hidden;

                        await Task.Delay(5000);
                        IsKeyIncorrect.Visibility = Visibility.Hidden;
                        dd.Visibility = Visibility.Visible;
                    }
                }
                else
                {
                    new Loader().Show();
                    this.Close();
                }
            }

        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Process.GetCurrentProcess().Kill();
        }

        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Rectangle_MouseLeftButtonDown_1(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void Border_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            DragMove();
        }
    }
}
