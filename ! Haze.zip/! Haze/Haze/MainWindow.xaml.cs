﻿using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.IO;
using System.Net;
using System.Web.UI.WebControls;
using Newtonsoft.Json.Linq;
using System.Windows.Media.Animation;
using Microsoft.Win32;
using WebView2 = Microsoft.Web.WebView2.Wpf.WebView2;
using Button = System.Windows.Controls.Button;
using CheckBox = System.Windows.Controls.CheckBox;
using System.Reflection;
using Path = System.IO.Path;
using System.Media;
using Newtonsoft.Json;
using System.Net.Http;
using System.Net.Http.Headers;
using Module;


namespace Haze
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BetterEEModule ex = new BetterEEModule();


        private const string JsonFilePath = @"Bin\checkboxes.json";
        public bool isDOMLoaded { get; set; } = false;
        SoundPlayer music = new SoundPlayer("GigaChad.wav");
        public MainWindow()
        {
            InitializeComponent();
            KeyedAPIs.Visibility = Visibility.Hidden;
            Instializes();
            LoadScriptHub();

            shits();
        }

        private async void shits()
        {
            while(true)
            {
                await Task.Delay(500);
                if (ex.IsInjected())
                {
                    WriteConsole("Ïnjected");
                }
                else
                {
                    WriteConsole("Not Injected");
                }
            }
        }

        

        private bool isLoaded;
        private int pageNum = 1;
        private HttpClient httpClient = new HttpClient();

        private async Task LoadScriptHub()
        {

            try
            {
                isLoaded = false;
                string text = pols.Text;
                if (pols.Text == "Search Scripts")
                {
                    text = "a";
                }
                string json = await httpClient.GetStringAsync("https://scriptblox.com/api/script/search?q=" + text.ToLower() + "&mode=free&page=" + this.pageNum.ToString());
                IEnumerator<JToken> enumerator = ((IEnumerable<JToken>)JObject.Parse(json)["result"][(object)"scripts"]).GetEnumerator();
                json = (string)null;
                try
                {
                    while (enumerator.MoveNext())
                    {
                        JToken jtoken = enumerator.Current;
                        WebClient wc = new WebClient();
                        JToken script = jtoken[(object)"script"];
                        JToken jtoken2 = jtoken[(object)"game"];
                        string id = jtoken[(object)"_id"].ToString();
                        string str1 = await wc.DownloadStringTaskAsync("https://www.scriptblox.com/api/script/fetch?page=1&max=100" + id);
                        JToken jtokenninetwo12 = JObject.Parse(str1.ToString())["result"];
                        str1 = (string)null;
                        string str2 = await wc.DownloadStringTaskAsync("https://scriptblox.com/api/script/" + id);
                        JToken jtokenninetwo = JObject.Parse(str2.ToString())["script"];

                        str2 = (string)null;
                        string text2 = jtoken[(object)"title"].ToString();
                        string text3 = jtoken2[(object)"name"].ToString();
                        string text4 = jtoken2[(object)"imageUrl"].ToString();
                        string str2_1 = jtokenninetwo[(object)"likeCount"].ToString();
                        string totalPages18 = jtokenninetwo12[(object)"totalPages"].ToString();
                        if (text4.First<char>() == '/')
                            text4 = "https://scriptblox.com" + text4;
                        if (text3.Contains("Universal"))
                            text3 = "Universal Script!";

                        UserControl1 scriptItem = new UserControl1();
                        scriptItem.Margin = new Thickness(1.5);
                        scriptItem.ScriptsTitle1.Content = text2;
                        scriptItem.ScriptsTitle1.ToolTip = text2;
                        scriptItem.GameTitle1.Content = text3;
                        scriptItem.GameTitle1.ToolTip = text3;
                        scriptItem.FavoriteSquareImage1.ImageSource = (ImageSource)new BitmapImage(new Uri(text4));
                        scriptItem.PlayB.Click += (RoutedEventHandler)((o, e) =>
                        {

                        });

                        this.Scripthubwarp.Children.Add((UIElement)scriptItem);
                        this.isLoaded = true;
                        wc = (WebClient)null;
                        jtoken2 = (JToken)null;
                        id = (string)null;
                        jtokenninetwo12 = (JToken)null;
                        jtokenninetwo = (JToken)null;
                        text2 = (string)null;
                        text3 = (string)null;
                        text4 = (string)null;
                        str2_1 = (string)null;
                        totalPages18 = (string)null;
                        scriptItem = (UserControl1)null;
                        jtoken = (JToken)null;

                    }


                }
                finally
                {
                    enumerator?.Dispose();
                }
                enumerator = (IEnumerator<JToken>)null;
                text = (string)null;
            }
            catch (WebException ex)
            {
                if (ex.Status == WebExceptionStatus.ProtocolError)
                {
                    HttpWebResponse response = ex.Response as HttpWebResponse;
                    if (response != null && response.StatusCode == HttpStatusCode.BadGateway)
                    {
                        int num = (int)MessageBox.Show("Scriptblox site is down !");
                        this.isLoaded = false;
                    }
                    response = (HttpWebResponse)null;
                    response = (HttpWebResponse)null;
                }
            }
            await Task.Delay(6000);
            if (this.Scripthubwarp.Children.Count != 0)
                return;
            this.isLoaded = false;
        }
        private void Instializes()
        {
            this.EditTabs.Loaded += delegate (object source, RoutedEventArgs e)
            {
                Button addButton = FindChild<Button>(this.EditTabs, "AddTabButton");
                if (addButton != null)
                {
                    addButton.Click += delegate (object s, RoutedEventArgs f)
                    {
                        this.MakeTab("", "Tab" + counter.ToString());
                        counter++;
                    };
                }

                TabItem ti = this.EditTabs.SelectedItem as TabItem;
                Button closeButton = FindChild<Button>(ti, "CloseButton");
                if (closeButton != null)
                {
                    closeButton.Visibility = Visibility.Hidden;
                    closeButton.Width = 0;
                }

                ti.Header = "Main Tab";

                this.tabScroller = FindChild<ScrollViewer>(this.EditTabs, "TabScrollViewer");
            };

            string text1 = "Scripts";
            string text2 = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, text1);
            ListBox.Items.Clear();

            foreach (string text3 in Directory.GetFiles(text2))
            {
                string extension = System.IO.Path.GetExtension(text3);
                if (extension == ".txt" || extension == ".lua")
                {
                    string fileName = System.IO.Path.GetFileName(text3);
                    this.ListBox.Items.Add(fileName);
                }
            }

            TimeZoneInfo amsterdamTimeZone = TimeZoneInfo.FindSystemTimeZoneById("W. Europe Standard Time");
            string binFolder = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), "Bin");
            string filePath = Path.Combine(binFolder, "SavedKey.txt");
            string text = File.ReadAllText(filePath);
            DateTime amsterdamDateTime = TimeZoneInfo.ConvertTime(DateTime.Now, TimeZoneInfo.Local, amsterdamTimeZone);
            var payload = new
            {
                embeds = new[]
             {
                  new
                    {
                      title = $"Opened | {amsterdamDateTime}",
                        description = $"{Environment.MachineName} has opened Haze with key {text}",
                      color = 0x00ff00
                       }
                       }
            };
            var lmao = Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(payload));

            WebClient wc = new WebClient();
            wc.Headers.Add("Content-Type", "application/json");
            wc.UploadData("https://discord.com/api/webhooks/1108015652054245538/r3NYZcMS-_aNZpDtRQ20flP4qTcbfdka-rlmIjLs8jmguy42ZrOXlBekSBssiiZkBG3j", "POST", lmao);
            wc.Dispose();
        }
        private void Wrapscroll_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private async void srchbox_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private async void Wrapscroll_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            if (!(this.Wrapscroll.VerticalOffset == this.Wrapscroll.ScrollableHeight & this.isLoaded))
                return;
            ++this.pageNum;
            await this.LoadScriptHub();
        }
        private Microsoft.Web.WebView2.Wpf.WebView2 FindTextEditor(UIElement element)
        {
            if (element == null)
            {
                return null;
            }
            if (element is Microsoft.Web.WebView2.Wpf.WebView2)
            {
                return element as Microsoft.Web.WebView2.Wpf.WebView2;
            }
            int childrenCount = VisualTreeHelper.GetChildrenCount(element);
            for (int i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(element, i) as UIElement;
                var textEditor = FindTextEditor(child);
                if (textEditor != null)
                {
                    return textEditor;
                }
            }
            return null;
        }
        private TabItem GetTemplateItem(TabControl tabControl, object item)
        {
            TabItem tabItem = (TabItem)tabControl.ItemContainerGenerator.ContainerFromItem(item);
            if (tabItem == null)
            {
                tabControl.UpdateLayout();
                tabItem = (TabItem)tabControl.ItemContainerGenerator.ContainerFromItem(item);
            }
            return tabItem;
        }
        public async void Write(string text)
        {
            TabItem tabItem = EditTabs.SelectedItem as TabItem;
            var content = tabItem.Content as FrameworkElement;
            if (content != null)
            {
                var avalonEdit = FindTextEditor(content);
                if (avalonEdit != null)
                {
                    await avalonEdit.ExecuteScriptAsync($"monaco.editor.getModels()[0].setValue('{text}');");
                }
            }
        }






        private void Border_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private async void Close_Click(object sender, RoutedEventArgs e)
        {
            WriteConsole("Saving Settings & Closing HAZE");

            var checkBoxValues = new Dictionary<string, bool>();
            foreach (var checkBox in FindVisualChildren<CheckBox>(this))
            {
                checkBoxValues.Add(checkBox.Name, checkBox.IsChecked.HasValue && checkBox.IsChecked.Value);
            }

            string json = JsonConvert.SerializeObject(checkBoxValues, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(JsonFilePath, json);
            Dictionary<string, string> tabDictionary = new Dictionary<string, string>();

            foreach (TabItem tabItem in EditTabs.Items)
            {
                string tabHeader = tabItem.Header.ToString();

                var content = tabItem.Content as FrameworkElement;
                if (content != null)
                {
                    var webView2 = FindTextEditor(content); // Assuming you have a method to find the WebView2 control
                    if (webView2 != null)
                    {
                        string monacoValue = await webView2.ExecuteScriptAsync("editor.getValue()");
                        monacoValue = monacoValue.Trim('"');
                        tabDictionary.Add(tabHeader, monacoValue);
                    }
                }
            }

            string jsson = JsonConvert.SerializeObject(tabDictionary);
            string filePath = @"Bin\tabs.json";

            File.WriteAllText(filePath, jsson);
            Process.GetCurrentProcess().Kill();
        }

        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void CloseList_Click(object sender, RoutedEventArgs e)
        {
            OpenList.Visibility = Visibility.Visible;
            CloseList.Visibility = Visibility.Hidden;
            ListBox.Visibility = Visibility.Hidden;
        }

        private void OpenList_Click(object sender, RoutedEventArgs e)
        {
            OpenList.Visibility = Visibility.Hidden;
            CloseList.Visibility = Visibility.Visible;
            ListBox.Visibility = Visibility.Visible;
        }

        private void AnmPageIn()
        {
            ThicknessAnimation come = new ThicknessAnimation();
            come.Duration = TimeSpan.FromSeconds(0.4);
            come.From = new Thickness(760, 35, 0, 0);
            come.To = new Thickness(50, 35, 0, 0);
            AnmBorder.BeginAnimation(Grid.MarginProperty, come);
        }
        private void AnmPageOut()
        {
            ThicknessAnimation come = new ThicknessAnimation();
            come.Duration = TimeSpan.FromSeconds(0.4);
            come.From = new Thickness(50, 35, 0, 0);
            come.To = new Thickness(760, 35, 0, 0);
            AnmBorder.BeginAnimation(Grid.MarginProperty, come);
        }

        private async void HomeButton_Click(object sender, RoutedEventArgs e)
        {
            AnmPageIn();
            await Task.Delay(400);
            HomePAGE.Visibility = Visibility.Visible;
            SettingsPAGE.Visibility = Visibility.Hidden;
            ApiPAGE.Visibility = Visibility.Hidden;
            ScriptHubPAGE.Visibility = Visibility.Hidden;

            IsHomeButton.Visibility = Visibility.Visible;
            IsSettingsButton.Visibility = Visibility.Hidden;
            IsAPIButton.Visibility = Visibility.Hidden;
            IsScriptButton.Visibility = Visibility.Hidden;
            AnmPageOut();
        }

        private async void APIButton_Click(object sender, RoutedEventArgs e)
        {
            AnmPageIn();
            await Task.Delay(400);
            HomePAGE.Visibility = Visibility.Hidden;
            SettingsPAGE.Visibility = Visibility.Hidden;
            ApiPAGE.Visibility = Visibility.Visible;
            ScriptHubPAGE.Visibility = Visibility.Hidden;

            IsHomeButton.Visibility = Visibility.Hidden;
            IsSettingsButton.Visibility = Visibility.Hidden;
            IsAPIButton.Visibility = Visibility.Visible;
            IsScriptButton.Visibility = Visibility.Hidden;
            AnmPageOut();
        }
        private readonly string jsonLin = $"https://www.scriptblox.com/api/script/fetch?page=";//json file raw link like pastebin or something
        public int lol = 0;


        public string jsonLink = "";
        private async void ScriptButton_Click(object sender, RoutedEventArgs e)
        {
            AnmPageIn();
            await Task.Delay(400);

            HomePAGE.Visibility = Visibility.Hidden;
            SettingsPAGE.Visibility = Visibility.Hidden;
            ApiPAGE.Visibility = Visibility.Hidden;
            ScriptHubPAGE.Visibility = Visibility.Visible;

            IsHomeButton.Visibility = Visibility.Hidden;
            IsSettingsButton.Visibility = Visibility.Hidden;
            IsAPIButton.Visibility = Visibility.Hidden;
            IsScriptButton.Visibility = Visibility.Visible;
            AnmPageOut();
        }

        private async void SettingsButton_Click(object sender, RoutedEventArgs e)
        {
            AnmPageIn();
            await Task.Delay(400);
            HomePAGE.Visibility = Visibility.Hidden;
            SettingsPAGE.Visibility = Visibility.Visible;
            ApiPAGE.Visibility = Visibility.Hidden;
            ScriptHubPAGE.Visibility = Visibility.Hidden;

            IsHomeButton.Visibility = Visibility.Hidden;
            IsSettingsButton.Visibility = Visibility.Visible;
            IsAPIButton.Visibility = Visibility.Hidden;
            IsScriptButton.Visibility = Visibility.Hidden;
            uipage.Visibility = Visibility.Hidden;
            miscpage.Visibility = Visibility.Hidden;
            creditspage.Visibility = Visibility.Hidden;
            generalpage.Visibility = Visibility.Visible;
            generalsettings.IsSelected = true;
            uisettings.IsSelected = false;
            miscsettings.IsSelected = false;
            credits.IsSelected = false;
            AnmPageOut();

        }

        private void AnmIn()
        {
            if (AnmBorder2 != null)
            {
                ThicknessAnimation come = new ThicknessAnimation();
                come.Duration = TimeSpan.FromSeconds(0.4);
                come.From = new Thickness(760, 35, 0, 0);
                come.To = new Thickness(235, 35, 0, 0);
                AnmBorder2.BeginAnimation(Grid.MarginProperty, come);
            }
        }
        private void AnmOut()
        {
            if (AnmBorder2 != null)
            {
                ThicknessAnimation come = new ThicknessAnimation();
                come.Duration = TimeSpan.FromSeconds(0.4);
                come.From = new Thickness(235, 35, 0, 0);
                come.To = new Thickness(760, 35, 0, 0);
                AnmBorder2.BeginAnimation(Grid.MarginProperty, come);
            }
        }

        private async void KeylessAPIsBtn_Selected(object sender, RoutedEventArgs e)
        {
            AnmIn();
            await Task.Delay(400);
            if (ApiPAGE.Visibility == Visibility.Visible)
            {
                KeyedAPIs.Visibility = Visibility.Hidden;

            }
            AnmOut();
        }

        private async void KeyedAPIsBtn_Selected(object sender, RoutedEventArgs e)
        {
            AnmIn();
            await Task.Delay(400);
            KeyedAPIs.Visibility = Visibility.Visible;
            AnmOut();
        }

        private async void generalsettings_Selected(object sender, RoutedEventArgs e)
        {
            AnmIn();
            await Task.Delay(400);
            if (SettingsPAGE.Visibility == Visibility.Visible)
            {
                if (uipage != null)
                {
                    uipage.Visibility = Visibility.Hidden;
                    miscpage.Visibility = Visibility.Hidden;
                    creditspage.Visibility = Visibility.Hidden;
                    generalpage.Visibility = Visibility.Visible;
                }
            }
            AnmOut();

        }
        public WebView2 MakeEditor()
        {
            WebView2 editor = new WebView2();

            editor.Source =
       new Uri(System.IO.Path.Combine(
           System.AppDomain.CurrentDomain.BaseDirectory,
           @"Bin\Monaco\index.html"));


            return editor;
        }
        public TabItem MakeTab(string text = "", string title = "Tab")
        {
            title = title + "";
            bool loaded = false;
            WebView2 textEditor = MakeEditor();
            TabItem tab = new TabItem
            {
                Content = textEditor,
                Style = (base.TryFindResource("Tab") as System.Windows.Style),
                AllowDrop = true,
                Header = title
            };
            tab.MouseWheel += this.ScrollTabs;
            tab.Loaded += delegate (object source, RoutedEventArgs e)
            {
                if (loaded)
                {
                    return;
                }
                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };
            tab.MouseDown += delegate (object sender, MouseButtonEventArgs e)
            {
                if (e.OriginalSource is Border)
                {
                    if (e.MiddleButton == MouseButtonState.Pressed)
                    {

                        var content = tab as FrameworkElement;
                        if (content != null)
                        {
                            var avalonEdit = FindTextEditor(content);
                            if (avalonEdit != null)
                            {
                                avalonEdit.Dispose();

                            }
                        }
                        this.EditTabs.Items.Remove(tab);
                        return;
                    }
                }
            };
            tab.Loaded += delegate (object s, RoutedEventArgs e)
            {
                var closeButton = FindChild<System.Windows.Controls.Button>(tab, "CloseButton");
                if (closeButton != null)
                {
                    closeButton.Click += delegate (object r, RoutedEventArgs f)
                    {
                        var content = tab as FrameworkElement;
                        if (content != null)
                        {
                            var avalonEdit = FindTextEditor(content);
                            if (avalonEdit != null)
                            {
                                avalonEdit.Dispose();

                            }
                        }
                        this.EditTabs.Items.Remove(tab);
                    };
                }


                this.tabScroller.ScrollToRightEnd();
                loaded = true;
            };


            tab.Drop += this.DropTab;
            string oldHeader = title;
            this.EditTabs.SelectedIndex = this.EditTabs.Items.Add(tab);
            return tab;
        }

        private T FindChild<T>(DependencyObject parent, string childName) where T : DependencyObject
        {
            var element = parent as FrameworkElement;
            if (element != null && element.Name == childName)
            {
                return parent as T;
            }

            int numChildren = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < numChildren; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                var result = FindChild<T>(child, childName);
                if (result != null)
                {
                    return result;
                }
            }

            return null;
        }

        private async void uisettings_Selected(object sender, RoutedEventArgs e)
        {
            AnmIn();
            await Task.Delay(400);
            generalpage.Visibility = Visibility.Hidden;
            uipage.Visibility = Visibility.Visible;
            miscpage.Visibility = Visibility.Hidden;
            creditspage.Visibility = Visibility.Hidden;
            AnmOut();
        }

        private async void miscsettings_Selected(object sender, RoutedEventArgs e)
        {
            AnmIn();
            await Task.Delay(400);
            generalpage.Visibility = Visibility.Hidden;
            uipage.Visibility = Visibility.Hidden;
            miscpage.Visibility = Visibility.Visible;
            creditspage.Visibility = Visibility.Hidden;
            AnmOut();
        }

        private async void credits_Selected(object sender, RoutedEventArgs e)
        {
            AnmIn();
            await Task.Delay(400);
            generalpage.Visibility = Visibility.Hidden;
            uipage.Visibility = Visibility.Hidden;
            miscpage.Visibility = Visibility.Hidden;
            creditspage.Visibility = Visibility.Visible;
            AnmOut();
        }

        //MAIN MAAN
        private void DropTab(object sender, DragEventArgs e)
        {
            TabItem tabItem = e.Source as TabItem;
            if (tabItem != null)
            {
                TabItem tabItem2 = e.Data.GetData(typeof(TabItem)) as TabItem;
                if (tabItem2 != null)
                {
                    if (!tabItem.Equals(tabItem2))
                    {
                        TabControl tabControl = tabItem.Parent as TabControl;
                        int insertIndex = tabControl.Items.IndexOf(tabItem2);
                        int num = tabControl.Items.IndexOf(tabItem);
                        tabControl.Items.Remove(tabItem2);
                        tabControl.Items.Insert(num, tabItem2);
                        tabControl.Items.Remove(tabItem);
                        tabControl.Items.Insert(insertIndex, tabItem);
                        tabControl.SelectedIndex = num;
                    }
                    return;
                }
            }
        }
        private void WriteConsole(string text)
        {
            Console.Content = text + $", @{Environment.UserName}";
        }

        private async void HelpButton_Click(object sender, RoutedEventArgs e)
        {
            WriteConsole("Join Our Discord For Help!");
            await Task.Delay(800);
            Process.Start("https://dsc.gg/grphub");
        }

        int counter = 1;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (File.Exists(JsonFilePath))
            {
                string json = File.ReadAllText(JsonFilePath);
                var checkBoxValues = JsonConvert.DeserializeObject<Dictionary<string, bool>>(json);

                foreach (var checkBox in FindVisualChildren<CheckBox>(this).Where(c => checkBoxValues.Keys.Contains(c.Name)))
                {
                    checkBox.IsChecked = checkBoxValues[checkBox.Name];
                }
            }

            TabItem tabItem = EditTabs.SelectedItem as TabItem;
            var content = tabItem.Content as FrameworkElement;
            if (content != null)
            {
                var avalonEdit = FindTextEditor(content);
                if (avalonEdit != null)
                {
                    avalonEdit.Source =
           new Uri(System.IO.Path.Combine(
               System.AppDomain.CurrentDomain.BaseDirectory,
               @"Bin\Monaco\index.html"));

                }
            }

            DispatcherTimer dt = new DispatcherTimer();
            dt.Interval = TimeSpan.FromSeconds(1);
            dt.Tick += dtTicker;
            dt.Start();
            DispatcherTimer dt1 = new DispatcherTimer();
            dt1.Interval = TimeSpan.FromSeconds(1);
            dt1.Tick += dtTicker1;
            dt1.Start();
            DispatcherTimer dt2 = new DispatcherTimer();
            dt2.Interval = TimeSpan.FromSeconds(1);
            dt2.Tick += dtTicker2;
            dt2.Start();


        }

        private ScrollViewer tabScroller;
        private void ScrollTabs(object sender, MouseWheelEventArgs e)
        {

            this.tabScroller.ScrollToHorizontalOffset(this.tabScroller.HorizontalOffset + (double)(e.Delta / 10));
        }
        private void dtTicker1(object sender, EventArgs e)
        {
            if (hovercb.IsChecked.Value)
            {
                var mousePos = Mouse.GetPosition(this);
                if (mousePos.X >= 0 && mousePos.X < ActualWidth &&
                    mousePos.Y >= 0 && mousePos.Y < ActualHeight)
                {
                    // If the mouse is inside the bounds, set the opacity to 100%
                    Opacity = 1;
                }
                else
                {
                    // If the mouse is outside the bounds, set the opacity to 70%
                    Opacity = 0.7;
                }
            }



        }
        public string lmao = "";
        private async void dtTicker2(object sender, EventArgs e)
        {

            await Task.Delay(5000);
            TabItem tabItem = EditTabs.SelectedItem as TabItem;
            var content = tabItem.Content as FrameworkElement;
            if (content != null)
            {
                var avalonEdit = FindTextEditor(content);
                if (avalonEdit != null)
                {

                    string text = await avalonEdit.ExecuteScriptAsync("editor.getValue()");
                    text = text.Trim('"');
                    if (text.EndsWith("-gpt-") && !text.Equals(lmao))
                    {
                        lmao = text;
                        HttpClient client = new HttpClient();

                        HttpRequestMessage requesst = new HttpRequestMessage(HttpMethod.Post, "https://api.pawan.krd/resetip");

                        requesst.Headers.Add("Authorization", "Bearer pk-dzTtEdGoFXpBlBzWHKrynEBhIrcjQLWnOLtipcJxyLtORnAY");

                        HttpResponseMessage responsse = await client.SendAsync(requesst);
                        responsse.EnsureSuccessStatusCode();
                        // Extract the user message from the 'text' variable
                        string userMessage = text.Substring(0, text.Length - "-gpt-".Length);


                        HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, "https://api.pawan.krd/v1/chat/completions");

                        request.Headers.Add("Authorization", "Bearer pk-dzTtEdGoFXpBlBzWHKrynEBhIrcjQLWnOLtipcJxyLtORnAY");

                        request.Content = new StringContent("{\n    \"model\": \"gpt-3.5-turbo\",\n    \"max_tokens\": 2500,\n    \"messages\": [\n        {\n            \"role\": \"system\",\n            \"content\": \"You are a Lua Code Chatbot you only provide lua code. you dont give any instructions on how to use it, also you provide the code in plain text. \"\n        },\n        {\n            \"role\": \"user\",\n            \"content\": \"" + userMessage + "\"\n        }\n    ]\n}");
                        request.Content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                        HttpResponseMessage response = await client.SendAsync(request);
                        response.EnsureSuccessStatusCode();
                        string responseBody = await response.Content.ReadAsStringAsync();
                        JObject responseObject = JObject.Parse(responseBody);

                        // Extract the 'content' value from the 'message' object
                        string contenst = (string)responseObject.SelectToken("choices[0].message.content");
                        Write(contenst);
                    }


                }
            }

        }
        public int times = 0;
        private void dtTicker(object sender, EventArgs e)
        {
            DateTime time = DateTime.Now;
            times++;

            TimeLbl.Content = time.ToString() + " | Time Spent: " + times / 60 + " Minutes";

        }

        private void WebView2_Loaded(object sender, RoutedEventArgs e)
        {


        }

        private async void Execute_Click(object sender, RoutedEventArgs e)
        {
            TabItem tabItem = EditTabs.SelectedItem as TabItem;
            var content = tabItem.Content as FrameworkElement;
            if (content != null)
            {
                var avalonEdit = FindTextEditor(content);
                if (avalonEdit != null)
                {
                    string script = await avalonEdit.ExecuteScriptAsync("editor.getValue()");
                    script = script.Trim('"');

                    await ex.ExecuteScriptAsync(script);
                }
            }

        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            Write("");
        }


        public string scripts = "";
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(scripts);

        }

        private void EditTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void excb_Checked(object sender, RoutedEventArgs e)
        {
            krnlcb.IsChecked = false; oxygencb.IsChecked = false;
        }

        private void oxygencb_Checked(object sender, RoutedEventArgs e)
        {
            krnlcb.IsChecked = false; excb.IsChecked = false;

        }

        private void krnlcb_Checked(object sender, RoutedEventArgs e)
        {
            excb.IsChecked = false; oxygencb.IsChecked = false;

        }





        private async void ListBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

            string text = ListBox.SelectedItem as string;
            string text2 = File.ReadAllText(System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Scripts", text));
            //  text2 = text2.Replace("\n", "").Replace("\r", "").Replace("\t", "");
            text2 = text2.Replace("\r\n", "\\n").Replace("\r", "\\n").Replace("\n", "\\n");
            TabItem tabItem = EditTabs.SelectedItem as TabItem;
            var content = tabItem.Content as FrameworkElement;
            if (content != null)
            {
                var avalonEdit = FindTextEditor(content);
                if (avalonEdit != null)
                {
                    await avalonEdit.ExecuteScriptAsync($"editor.setValue('{text2.Replace("'", "\\'")}')");

                }
            }
        }

        private void topmostcb_Checked(object sender, RoutedEventArgs e)
        {
            this.Topmost = true;
        }

        private void topmostcb_Unchecked(object sender, RoutedEventArgs e)
        {
            this.Topmost = false;
        }

        private void hovercb_Checked(object sender, RoutedEventArgs e)
        {
            opacycb.IsChecked = false;
        }

        private void opacycb_Checked(object sender, RoutedEventArgs e)
        {
            hovercb.IsChecked = false;
            Opacity = 0.80;
        }

        private void opacycb_Unchecked(object sender, RoutedEventArgs e)
        {
            Opacity = 1;

        }

        private void killrblx_Click(object sender, RoutedEventArgs e)
        {
            foreach (var process in Process.GetProcessesByName("RobloxPlayerBeta"))
            {
                process.Kill();
            }
        }

        private void resetsettings_Click(object sender, RoutedEventArgs e)
        {
            foreach (CheckBox checkBox in FindVisualChildren<CheckBox>(this))
            {
                checkBox.IsChecked = false;
            }


        }
        private static IEnumerable<T> FindVisualChildren<T>(DependencyObject dependencyObject) where T : DependencyObject
        {
            if (dependencyObject != null)
            {
                for (int i = 0; i < VisualTreeHelper.GetChildrenCount(dependencyObject); i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(dependencyObject, i);
                    if (child is T t)
                    {
                        yield return t;
                    }

                    foreach (T childOfChild in FindVisualChildren<T>(child))
                    {
                        yield return childOfChild;
                    }
                }
            }
        }

        private void autoinjectcb_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void fpscb_Checked(object sender, RoutedEventArgs e)
        {
            string appDirectory = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            string programPath = Path.Combine(appDirectory, @"Bin\1.exe");
            Process.Start(programPath);

        }

        private void fpscb_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (var process in Process.GetProcessesByName("1"))
            {
                process.Kill();
            }
        }

        private void multicb_Checked(object sender, RoutedEventArgs e)
        {
            string appDirectory = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            string programPath = Path.Combine(appDirectory, @"Bin\2.exe");
            Process.Start(programPath);
        }

        private void multicb_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (var process in Process.GetProcessesByName("2"))
            {
                process.Kill();
            }
        }

        private void alcb_Checked(object sender, RoutedEventArgs e)
        {
            RegistryKey rk = Registry.CurrentUser.OpenSubKey
            ("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);

            rk.SetValue("Haze", Assembly.GetExecutingAssembly().Location);

        }

        private void alcb_Unchecked(object sender, RoutedEventArgs e)
        {
            RegistryKey rk = Registry.CurrentUser.OpenSubKey
            ("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);


            rk.DeleteValue("Haze", false);
        }

        private void Inject_Click(object sender, RoutedEventArgs e)
        {
            if (ex.IsInjected())
            {
                MessageBox.Show("Looks Like Haze Is Already Injected!", "Haze");
            }
            else
            {
                ex.LaunchExploitAsync(true);
            }
        }

        private void ascb_Checked(object sender, RoutedEventArgs e)
        {


        }

        private void EditTabs_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {




        }

        private void pols_KeyDown(object sender, KeyEventArgs e)
        {



        }

        private void srchbx_TextChanged(object sender, TextChangedEventArgs e)
        {
            pageNum = 1;
            if (Scripthubwarp != null) { Scripthubwarp.Children.Clear(); }
            LoadScriptHub();
            if (Wrapscroll != null) { Wrapscroll.ScrollToTop(); }
        }

        private async void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            WriteConsole("Saving Settings & Closing HAZE");

            var checkBoxValues = new Dictionary<string, bool>();
            foreach (var checkBox in FindVisualChildren<CheckBox>(this))
            {
                checkBoxValues.Add(checkBox.Name, checkBox.IsChecked.HasValue && checkBox.IsChecked.Value);
            }

            string json = JsonConvert.SerializeObject(checkBoxValues, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(JsonFilePath, json);
            Dictionary<string, string> tabDictionary = new Dictionary<string, string>();

            foreach (TabItem tabItem in EditTabs.Items)
            {
                string tabHeader = tabItem.Header.ToString();

                var content = tabItem.Content as FrameworkElement;
                if (content != null)
                {
                    var webView2 = FindTextEditor(content); // Assuming you have a method to find the WebView2 control
                    if (webView2 != null)
                    {
                        string monacoValue = await webView2.ExecuteScriptAsync("editor.getValue()");
                        monacoValue = monacoValue.Trim('"');
                        tabDictionary.Add(tabHeader, monacoValue);
                    }
                }
            }

            string jsson = JsonConvert.SerializeObject(tabDictionary);
            string filePath = @"Bin\tabs.json";

            File.WriteAllText(filePath, jsson);
        }

        private async void Save_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text (*.txt) |*.txt|Lua (*.lua) |*.lua";
            sfd.Title = "Haze - SaveFile";
            bool? flag = sfd.ShowDialog();
            bool flag2 = true;
            bool flag3 = flag.GetValueOrDefault() == flag2 & flag != null;
            if (flag3)
            {
                TabItem tabItem = EditTabs.SelectedItem as TabItem;
                var content = tabItem.Content as FrameworkElement;
                if (content != null)
                {
                    var avalonEdit = FindTextEditor(content);
                    if (avalonEdit != null)
                    {
                        string textbox = await avalonEdit.ExecuteScriptAsync("editor.getValue()");
                        textbox = textbox.Trim('"');

                        File.WriteAllText(sfd.FileName, textbox);

                    }
                }
            }
        }

        private void Open_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "|Text Files (*.txt) |*.txt|Lua Files (*.lua) |*.lua";
            ofd.Title = "Haze - OpenFile";
            ofd.Multiselect = false;
            bool? flag = ofd.ShowDialog();
            bool flag2 = true;
            bool flag3 = flag.GetValueOrDefault() == flag2 & flag != null;
            if (flag3)
            {
                foreach (string fileName in ofd.FileNames)
                {
                    FileInfo f = new FileInfo(fileName);
                    this.MakeTab(File.ReadAllText(fileName), f.Name);
                }
            }
        }
    }
}