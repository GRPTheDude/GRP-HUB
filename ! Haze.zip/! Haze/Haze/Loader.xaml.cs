﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Haze
{
    /// <summary>
    /// Interaction logic for Loader.xaml
    /// </summary>
    public partial class Loader : Window
    {
        public Loader()
        {
            InitializeComponent();
            Load();
        }

        private async void Load()
        {
            await Task.Delay(1500);
            ThicknessAnimation come = new ThicknessAnimation();
            come.Duration = TimeSpan.FromSeconds(5);
            come.From = new Thickness(-454, 300, 0, 0);
            come.To = new Thickness(-1, 300, 0, 0);
            progress.BeginAnimation(Grid.MarginProperty, come);
            await Task.Delay(1000);

            Loads.Content = "Checking Version";
            /// ADD HAZE VERSION'S JSON SITE TO CHECK VERSION

            await Task.Delay(1500);
            Loads.Content = "Checking For Updates";
            /// ADD HAZE VERSION'S JSON SITE TO CHECK VERSION AND SEND A MESSAGEBOX IF OUTDATED

            await Task.Delay(1500);
            Loads.Content = "Checking Saved Tabs & Scripts";

            await Task.Delay(2000);

            HazeAnime();
        }

        private async void HazeAnime()
        {
            DoubleAnimation LwAnime = new DoubleAnimation(0, new Duration(TimeSpan.FromSeconds(0.8)));
            LoaderGrid.BeginAnimation(WidthProperty, LwAnime);

            await Task.Delay(600);
            new MainWindow().Show();
            this.Close();
        }
    }
}
